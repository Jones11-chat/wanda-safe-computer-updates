param(
    [string]$EnvName = "OPENAI_API_KEY"
)

$ErrorActionPreference = "Stop"

$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator
)

if (-not $isAdmin) {
    Write-Host "Restarting as Administrator..."
    Start-Process powershell.exe -Verb RunAs -ArgumentList @(
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        "`"$PSCommandPath`"",
        "-EnvName",
        "`"$EnvName`""
    )
    exit
}

Write-Host "Paste the OpenAI API key for testing. It will not be shown on screen."
$secure = Read-Host "OpenAI API key" -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)

try {
    $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    if ([string]::IsNullOrWhiteSpace($plain)) {
        throw "No key was entered."
    }

    [Environment]::SetEnvironmentVariable($EnvName, $plain, "Machine")
    Write-Host ""
    Write-Host "$EnvName was stored as a Machine environment variable."
    Write-Host "Restart Wanda's launcher, sign out/in, or reboot before testing the helper."
} finally {
    if ($ptr -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
    }
}
