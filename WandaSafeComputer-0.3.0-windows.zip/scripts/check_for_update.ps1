param(
    [string]$ConfigPath = "C:\ProgramData\Secure Tech Solutions\WandaSafeComputer\updater_config.json",
    [switch]$Force
)

$ErrorActionPreference = "Stop"

function Write-UpdateLog {
    param(
        [string]$Message,
        [string]$Level = "INFO"
    )

    $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "$stamp [$Level] $Message"
    Write-Host $line
    Add-Content -LiteralPath $script:LogPath -Value $line
}

function Compare-VersionString {
    param(
        [string]$Current,
        [string]$Latest
    )

    try {
        $currentVersion = [Version]$Current
        $latestVersion = [Version]$Latest
        return $latestVersion.CompareTo($currentVersion)
    } catch {
        if ($Latest -ne $Current) {
            return 1
        }
        return 0
    }
}

if (-not (Test-Path -LiteralPath $ConfigPath)) {
    throw "Updater config not found: $ConfigPath"
}

$config = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json

if (-not $config.enabled -and -not $Force) {
    return
}

$installFolder = [Environment]::ExpandEnvironmentVariables($config.install_folder)
$downloadFolder = [Environment]::ExpandEnvironmentVariables($config.download_folder)
$logFolder = [Environment]::ExpandEnvironmentVariables($config.log_folder)

New-Item -ItemType Directory -Path $downloadFolder -Force | Out-Null
New-Item -ItemType Directory -Path $logFolder -Force | Out-Null

$script:LogPath = Join-Path $logFolder ("update-" + (Get-Date -Format "yyyy-MM") + ".log")

try {
    Write-UpdateLog "Checking for updates."

    $currentVersionPath = Join-Path $installFolder "VERSION"
    $currentVersion = if (Test-Path -LiteralPath $currentVersionPath) {
        (Get-Content -LiteralPath $currentVersionPath -Raw).Trim()
    } else {
        "0.0.0"
    }

    $manifest = Invoke-RestMethod -Uri $config.manifest_url -Method Get -TimeoutSec 30 -Headers @{
        "Cache-Control" = "no-cache"
    }

    if (-not $manifest.version -or -not $manifest.package_url -or -not $manifest.sha256) {
        throw "Update manifest is missing version, package_url, or sha256."
    }

    $comparison = Compare-VersionString -Current $currentVersion -Latest $manifest.version
    if ($comparison -le 0 -and -not $Force) {
        Write-UpdateLog "Already current. Installed=$currentVersion Latest=$($manifest.version)."
        return
    }

    Write-UpdateLog "Update available. Installed=$currentVersion Latest=$($manifest.version)."

    $packageName = if ($manifest.package_name) {
        [string]$manifest.package_name
    } else {
        "WandaSafeComputer-$($manifest.version)-windows.zip"
    }
    $packagePath = Join-Path $downloadFolder $packageName

    Invoke-WebRequest -Uri $manifest.package_url -OutFile $packagePath -UseBasicParsing -TimeoutSec 180

    $actualHash = (Get-FileHash -LiteralPath $packagePath -Algorithm SHA256).Hash.ToUpperInvariant()
    $expectedHash = ([string]$manifest.sha256).ToUpperInvariant()
    if ($actualHash -ne $expectedHash) {
        Remove-Item -LiteralPath $packagePath -Force -ErrorAction SilentlyContinue
        throw "Downloaded update hash did not match manifest."
    }

    $installer = Join-Path $installFolder "scripts\install_update_zip.ps1"
    if (-not (Test-Path -LiteralPath $installer)) {
        throw "Update installer not found: $installer"
    }

    Write-UpdateLog "Installing update package: $packagePath"
    & $installer -PackagePath $packagePath
    Write-UpdateLog "Update installed successfully."
} catch {
    Write-UpdateLog $_.Exception.Message "ERROR"
    exit 1
}
