param(
    [Parameter(Mandatory = $true)]
    [string]$PackagePath,

    [string]$InstallFolder = "C:\ProgramData\Secure Tech Solutions\WandaSafeComputer",

    [switch]$RestartLauncher
)

$ErrorActionPreference = "Stop"

$resolvedPackage = (Resolve-Path -LiteralPath $PackagePath).Path

$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator
)

if (-not $isAdmin) {
    $argsList = @(
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        "`"$PSCommandPath`"",
        "-PackagePath",
        "`"$resolvedPackage`"",
        "-InstallFolder",
        "`"$InstallFolder`""
    )
    if ($RestartLauncher) {
        $argsList += "-RestartLauncher"
    }
    Start-Process powershell.exe -Verb RunAs -ArgumentList $argsList
    exit
}

$tempRoot = Join-Path $env:TEMP ("WandaSafeComputerUpdate_" + [Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

try {
    Expand-Archive -LiteralPath $resolvedPackage -DestinationPath $tempRoot -Force

    $candidateRoots = @(
        $tempRoot,
        (Join-Path $tempRoot "WandaSafeComputer")
    )

    $packageRoot = $candidateRoots | Where-Object {
        Test-Path -LiteralPath (Join-Path $_ "WandaSafeComputer.exe")
    } | Select-Object -First 1

    if (-not $packageRoot) {
        throw "Package does not contain WandaSafeComputer.exe at the expected location."
    }

    New-Item -ItemType Directory -Path $InstallFolder -Force | Out-Null

    $runningLauncher = Get-Process -Name "WandaSafeComputer" -ErrorAction SilentlyContinue
    if ($runningLauncher) {
        $runningLauncher | Stop-Process -Force
        Start-Sleep -Seconds 2
    }

    Copy-Item -LiteralPath (Join-Path $packageRoot "WandaSafeComputer.exe") -Destination (Join-Path $InstallFolder "WandaSafeComputer.exe") -Force

    $sourceInternal = Join-Path $packageRoot "_internal"
    if (Test-Path -LiteralPath $sourceInternal) {
        $installedInternal = Join-Path $InstallFolder "_internal"
        if (Test-Path -LiteralPath $installedInternal) {
            Remove-Item -LiteralPath $installedInternal -Recurse -Force
        }
        Copy-Item -LiteralPath $sourceInternal -Destination $installedInternal -Recurse -Force
    }

    $copyNames = @(
        "VERSION",
        "config.json",
        "updater_config.json",
        "README.md",
        "HANDOFF_PRINT_OUT.md",
        "set_openai_key.ps1",
        "launch_for_wanda.cmd",
        "update_installed_launcher.ps1"
    )

    foreach ($name in $copyNames) {
        $source = Join-Path $packageRoot $name
        if (Test-Path -LiteralPath $source) {
            Copy-Item -LiteralPath $source -Destination (Join-Path $InstallFolder $name) -Force
        }
    }

    $scriptsFolder = Join-Path $InstallFolder "scripts"
    New-Item -ItemType Directory -Path $scriptsFolder -Force | Out-Null
    $scriptNames = @(
        "install_update_zip.ps1",
        "check_for_update.ps1",
        "install_auto_updater_task.ps1"
    )

    foreach ($scriptName in $scriptNames) {
        $scriptSource = Join-Path $packageRoot "scripts\$scriptName"
        if (Test-Path -LiteralPath $scriptSource) {
            Copy-Item -LiteralPath $scriptSource -Destination (Join-Path $scriptsFolder $scriptName) -Force
        }
    }

    $version = if (Test-Path -LiteralPath (Join-Path $packageRoot "VERSION")) {
        (Get-Content -LiteralPath (Join-Path $packageRoot "VERSION") -Raw).Trim()
    } else {
        "unknown"
    }

    "Updated to $version from $resolvedPackage at $(Get-Date -Format s)" | Set-Content -LiteralPath (Join-Path $InstallFolder "last-update.txt")

    if ($RestartLauncher) {
        Start-Process -FilePath (Join-Path $InstallFolder "WandaSafeComputer.exe")
    }

    Write-Host "Wanda's Safe Computer updated to version $version."
} finally {
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
