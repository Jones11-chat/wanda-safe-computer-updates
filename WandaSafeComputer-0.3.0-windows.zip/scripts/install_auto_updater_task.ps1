param(
    [string]$InstallFolder = "C:\ProgramData\Secure Tech Solutions\WandaSafeComputer",
    [string]$TaskName = "Secure Tech Wanda Safe Computer Updater"
)

$ErrorActionPreference = "Stop"

$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator
)

if (-not $isAdmin) {
    Start-Process powershell.exe -Verb RunAs -ArgumentList @(
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        "`"$PSCommandPath`"",
        "-InstallFolder",
        "`"$InstallFolder`"",
        "-TaskName",
        "`"$TaskName`""
    )
    exit
}

$updater = Join-Path $InstallFolder "scripts\check_for_update.ps1"
$config = Join-Path $InstallFolder "updater_config.json"

if (-not (Test-Path -LiteralPath $updater)) {
    throw "Updater script not found: $updater"
}

if (-not (Test-Path -LiteralPath $config)) {
    throw "Updater config not found: $config"
}

$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$updater`" -ConfigPath `"$config`""
$hourlyTrigger = New-ScheduledTaskTrigger -Once -At (Get-Date).Date.AddMinutes(10) -RepetitionInterval (New-TimeSpan -Hours 1) -RepetitionDuration (New-TimeSpan -Days 3650)
$logonTrigger = New-ScheduledTaskTrigger -AtLogOn
$settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable `
    -WakeToRun `
    -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 15)
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

Register-ScheduledTask `
    -TaskName $TaskName `
    -Action $action `
    -Trigger @($hourlyTrigger, $logonTrigger) `
    -Settings $settings `
    -Principal $principal `
    -Description "Checks for Wanda Safe Computer launcher updates and installs verified packages." `
    -Force | Out-Null

Write-Host "Installed scheduled task: $TaskName"
Write-Host "The laptop will check for updates at logon and about once per hour."
