# GitHub Setup

This project is ready to push to a private GitHub repository.

## Create Private Repo

Create a private repo on GitHub, for example:

```text
wanda-safe-computer
```

Do not add a README, license, or `.gitignore` on GitHub because this folder already has them.

## Push From This Windows Laptop

From this folder:

```powershell
cd "C:\Users\jones\Documents\Codex\2026-07-07\a\outputs\wanda_safe_laptop_launcher"
git add .
git commit -m "Initial Wanda Safe Computer launcher"
git remote add origin https://github.com/YOUR-USERNAME/wanda-safe-computer.git
git push -u origin main
```

If `git` is not on PATH on this laptop, use GitHub Desktop or push from the Mac instead.

## Push From Mac

Copy this project folder to the Mac, then:

```bash
cd wanda_safe_laptop_launcher
git add .
git commit -m "Initial Wanda Safe Computer launcher"
git remote add origin https://github.com/YOUR-USERNAME/wanda-safe-computer.git
git branch -M main
git push -u origin main
```

## Build From GitHub

Every push to `main` runs:

```text
.github/workflows/build-windows.yml
```

The workflow builds a Windows ZIP artifact.

## Automatic Download To Wanda's Laptop

Use two repos:

- `wanda-safe-computer` private source repo
- `wanda-safe-computer-updates` public update repo

The public update repo only contains compiled update files:

- `latest.json`
- `WandaSafeComputer-<version>-windows.zip`

Wanda's laptop checks this file:

```text
https://raw.githubusercontent.com/Jones11-chat/wanda-safe-computer-updates/main/latest.json
```

When `latest.json` points to a newer version, the laptop downloads the ZIP, verifies the SHA256 hash, and installs it.

To publish these files automatically from GitHub Actions:

1. Create a second GitHub repo named:

```text
wanda-safe-computer-updates
```

2. Make that repo **Public**.
3. Create a fine-grained GitHub token that can write contents to only `wanda-safe-computer-updates`.
4. In the private `wanda-safe-computer` repo, add a repository secret:

```text
UPDATE_REPO_TOKEN
```

5. Paste the fine-grained token as that secret.

After that, every push to `main` builds the Windows ZIP and publishes the latest update files to the public updates repo.

Install the scheduled updater once on Wanda's laptop:

```powershell
cd "C:\ProgramData\Secure Tech Solutions\WandaSafeComputer"
.\scripts\install_auto_updater_task.ps1
```

After that, updates are automatic at logon and about once per hour while the laptop is on.

## Make A Release

Update `VERSION`, commit, then tag:

```bash
git tag v0.1.1
git push origin v0.1.1
```

GitHub Actions creates a release and attaches the Windows ZIP.

## Install On Wanda's Laptop

Download the ZIP on Wanda's laptop, then:

```powershell
cd "C:\ProgramData\Secure Tech Solutions\WandaSafeComputer"
.\scripts\install_update_zip.ps1 -PackagePath "$env:USERPROFILE\Downloads\WandaSafeComputer-0.1.1-windows.zip"
```

No reboot is required.

## Secret Rule

Never commit:

- OpenAI API keys
- Windows passwords
- 1Password secrets
- Bank credentials
- BitLocker recovery keys

The OpenAI key stays on Wanda's laptop as:

```text
OPENAI_API_KEY
```
