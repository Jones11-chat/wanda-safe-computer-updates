@echo off
if /I not "%USERNAME%"=="Wanda" exit /b 0
start "" "C:\ProgramData\Secure Tech Solutions\WandaSafeComputer\WandaSafeComputer.exe"
