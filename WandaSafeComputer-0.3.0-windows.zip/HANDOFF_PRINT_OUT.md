# Wanda's Safe Computer - Handoff Notes

## Support

Included with setup:

- 30 days of free remote support
- Help with passwords, email, browser questions, suspicious pop-ups, and basic app questions

After 30 days:

- Optional support plan: $50/month
- Includes up to 4 hours/month of remote support
- In-home visits are billed separately

## Important Safety Rule

If a pop-up, caller, email, or text says the computer is infected or money is urgent:

Stop. Do not call the number on the screen. Text Hunter Jones at Secure Tech Solutions first.

## Setup Day Review

Bring:

- Cell phone for text codes
- Gmail login
- Huntington Bank login
- Facebook login
- iCloud login
- Amazon login
- Walmart login
- Pharmacy or doctor portal login, if used
- Printer model and Wi-Fi password
- Utility/bill websites to review later

## Wanda's Helper Rule

Wanda can use Ask Wanda's Helper for simple questions, writing help, recipes, and explaining confusing messages.

Do not type passwords, bank codes, Social Security numbers, credit cards, gift card numbers, or private medical/legal details into the helper.

If money, bank access, scary pop-ups, remote access, urgency, or gift cards are involved:

Stop and text Hunter first.

## Safe Buttons Included

- Type / Print Documents
- Gmail
- Facebook
- Messenger
- Huntington Bank
- Facebook Live
- iCloud Photos
- YouTube
- Walmart
- Amazon
- Bible / Daily Verse
- Ask Wanda's Helper
- Recipes
- Weather for Booneville, MS
- Print / Scan Help
- Scam Check
- Text Hunter / Get Help, with Remote Support inside
- 1Password
- Shut Down
