# Wanda Safe Laptop Launcher

A simple Windows launcher for an elderly user. It provides large safe buttons, approved website links, local scam report saving, support instructions, an optional OpenAI-powered helper, and an admin-only setup checklist.

## Files

- `wanda_launcher.py` - main launcher app
- `config.json` - editable settings, approved websites, paths, and button labels
- `set_openai_key.ps1` - admin helper to store or replace the OpenAI API key for Wanda's Helper
- `setup_checklist_state.json` - created automatically inside the local logs folder when the hidden checklist is saved
- `Scam Reports` - created in Wanda's Documents folder by default
- `Wanda Safe Laptop Logs` - created in Wanda's Documents folder by default
- `Documents/Wanda Materials` - created for documents

## Run

Install Python 3.11+ for Windows, then run:

```powershell
python wanda_launcher.py
```

On the final laptop, make a desktop shortcut that runs the packaged `.exe` or this script.

## Edit Approved Websites

Open `config.json` and edit `approved_websites`.

Example:

```json
"bank": {
  "label": "Bank",
  "url": "https://www.real-bank-website.com/"
}
```

Use only full `https://` URLs. The launcher does not include a search box.

Check your edits:

```powershell
python validate_config.py
```

## Browser Behavior

By default, website buttons use one Edge page at a time. When Wanda clicks a different website button, the launcher closes the existing Edge session and opens the selected approved site in a fresh Edge window. This keeps tabs from piling up.

## Hidden Admin Checklist

Press:

```text
Ctrl + Shift + A
```

This opens the setup checklist for Hunter. Wanda does not need this screen.

## Ask Wanda's Helper

The `Ask Wanda's Helper` button uses the OpenAI Responses API when `OPENAI_API_KEY` is available to the launcher process.

Recommended setup:

1. Create a separate OpenAI project/key for this laptop or customer group.
2. Set a monthly spend limit in OpenAI.
3. Store the key as a Windows Machine environment variable so Wanda's standard account can read it.
4. Restart the launcher or reboot after changing the key.

Run this from the launcher folder:

```powershell
.\set_openai_key.ps1
```

Do not hardcode the key in `config.json` or `wanda_launcher.py`. The helper does not save Wanda's questions to the log; it only logs that the helper was used or that an API call failed.

## Package Into an EXE

Install PyInstaller:

```powershell
python -m pip install pyinstaller
```

Build:

```powershell
python -m PyInstaller --noconsole --onefile --name WandaSafeComputer wanda_launcher.py
```

Copy `config.json` next to the generated `.exe` if you want to edit websites without rebuilding. The app looks for `config.json` beside the `.exe`.

Alternative folder build:

```powershell
python -m PyInstaller --noconsole --onedir --name WandaSafeComputer wanda_launcher.py
```

The `--onedir` build is easier to maintain because `config.json` can sit beside the executable.

## Update Without Rebooting

The laptop does not need to restart for launcher updates.

Config-only update:

1. Edit `config.json`.
2. Copy it to:

```text
C:\ProgramData\Secure Tech Solutions\WandaSafeComputer\config.json
```

3. Close and reopen Wanda's launcher.

Code update:

1. Rebuild the app:

```powershell
python -m PyInstaller WandaSafeComputer.spec --clean --noconfirm
```

2. Run:

```powershell
.\update_installed_launcher.ps1
```

This closes the launcher, copies the new build and config into ProgramData, and leaves the laptop running. Add `-RestartLauncher` if you want it reopened automatically:

```powershell
.\update_installed_launcher.ps1 -RestartLauncher
```

When using `-RestartLauncher` from an elevated/admin shell, the app may reopen under the admin session. If updating remotely while Wanda is signed in, the cleanest workflow is usually to update, then reopen from Wanda's desktop shortcut.

## Long-Term GitHub Update Workflow

Use this when editing from a MacBook or another computer.

### One-Time Setup

1. Create a private GitHub repository, for example:

```text
wanda-safe-computer
```

2. Push this launcher folder to the repo.
3. Keep `OPENAI_API_KEY` out of GitHub. The key stays on Wanda's laptop as a Windows environment variable.

### Edit From Mac

1. Clone the private repo on the Mac.
2. Edit `wanda_launcher.py`, `config.json`, or docs.
3. Update `VERSION` when making a release.
4. Commit and push to `main`.

GitHub Actions will build the Windows app automatically using `.github/workflows/build-windows.yml`.

## Automatic Updates To Wanda's Laptop

The launcher supports automatic updates. The source repo can stay private, but the finished update package must be downloadable by Wanda's laptop without a secret.

Recommended setup:

- Private source repo: `wanda-safe-computer`
- Public updates repo: `wanda-safe-computer-updates`

The public updates repo only needs:

- `latest.json`
- the latest `WandaSafeComputer-<version>-windows.zip`

No passwords or API keys belong in either file.

Wanda's laptop checks:

```text
https://raw.githubusercontent.com/Jones11-chat/wanda-safe-computer-updates/main/latest.json
```

To make publishing fully automatic, create a fine-grained GitHub token with write access to only the public updates repo, then save it as a secret named `UPDATE_REPO_TOKEN` in the private source repo. After that, every push to `main` builds and publishes the latest update ZIP automatically.

To enable automatic updates on Wanda's laptop, run once as admin:

```powershell
cd "C:\ProgramData\Secure Tech Solutions\WandaSafeComputer"
.\scripts\install_auto_updater_task.ps1
```

After that, the laptop checks for updates at logon and about once per hour while it is on.

To publish an update manually:

1. Download the GitHub Actions ZIP artifact.
2. Put the ZIP in the public updates repo.
3. Generate `latest.json` with the ZIP URL and hash:

```powershell
.\scripts\make_latest_manifest.ps1 `
  -PackagePath ".\WandaSafeComputer-0.1.1-windows.zip" `
  -PackageUrl "https://raw.githubusercontent.com/Jones11-chat/wanda-safe-computer-updates/main/WandaSafeComputer-0.1.1-windows.zip" `
  -Version "0.1.1" `
  -OutputPath ".\latest.json"
```

4. Commit and push the ZIP plus `latest.json` to the public updates repo.

Wanda's laptop will download and install it automatically the next time it checks.

### Get the Windows Build

For normal test builds:

1. Open the GitHub repo.
2. Go to **Actions**.
3. Open the latest successful **Build Windows Release** run.
4. Download the `WandaSafeComputer-windows` artifact.

For real releases:

1. Tag a version, such as `v0.1.1`.
2. Push the tag.
3. GitHub Actions creates a GitHub Release with the Windows ZIP attached.

### Install a ZIP Update on Wanda's Laptop

Remote into Wanda's laptop with Splashtop, download the ZIP, then run:

```powershell
cd "C:\ProgramData\Secure Tech Solutions\WandaSafeComputer"
.\scripts\install_update_zip.ps1 -PackagePath "$env:USERPROFILE\Downloads\WandaSafeComputer-0.1.1-windows.zip"
```

This does not reboot the laptop. It closes the launcher if needed, installs the new files, and records `last-update.txt`.

To reopen the launcher, use Wanda's desktop shortcut. Avoid using `-RestartLauncher` from an elevated/admin session unless you specifically want it opened in that session.

### Local Windows Build

If you are working directly on a Windows computer:

```powershell
.\scripts\build_release.ps1
```

The ZIP will be created under:

```text
release\
```

## Recommended Startup Shortcut

Create a shortcut to:

```text
WandaSafeComputer.exe
```

Place it on Wanda's desktop or in:

```text
%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
```

This folder also includes:

```powershell
.\create_desktop_shortcut.ps1
```

Run that after packaging to create a desktop shortcut named `Wanda's Safe Computer`.

## Safety Notes

- The launcher does not store passwords.
- The launcher does not store the OpenAI API key in code or config.
- The password button opens a real password manager if installed.
- Scam reports are saved locally only.
- The launcher does not disable Defender, SmartScreen, or Windows warnings.
- It does not need admin privileges to run.
- Remote support defaults to Windows Quick Assist. Wanda should text Hunter first, then open remote support.

## Setup Day

With Wanda present:

- Sign into 1Password.
- Set up OneDrive backup.
- Add email, bank, pharmacy, doctor, phone, shopping, and streaming logins.
- Ask whether utilities/bills should be added later.
- Set up printer and scanner.
- Test scam report saving.
- Test Ask Wanda's Helper with a simple question.
- Explain the rule: text Hunter before opening Remote Support.
- Explain support: 30 days included, then $50/month for up to 4 hours of remote support. In-home visits billed separately.
