# Release Checklist

## Before Pushing

- Update `VERSION`.
- Run `python validate_config.py`.
- Confirm no API keys or passwords are in the repo.
- Commit changes.

## GitHub Build

- Push to `main` for a test build.
- Check the **Build Windows Release** action.
- Download the `WandaSafeComputer-windows` artifact.

## Tagged Release

```powershell
git tag v0.1.1
git push origin v0.1.1
```

GitHub Actions will attach a Windows ZIP to the GitHub Release.

## Install On Wanda's Laptop

```powershell
cd "C:\ProgramData\Secure Tech Solutions\WandaSafeComputer"
.\scripts\install_update_zip.ps1 -PackagePath "$env:USERPROFILE\Downloads\WandaSafeComputer-0.1.1-windows.zip"
```

No reboot is required. Reopen the launcher from Wanda's desktop shortcut.
