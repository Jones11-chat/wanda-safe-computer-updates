# Packaging Notes

## Best Option

Use Python + PyInstaller with `--onedir`.

This keeps `config.json` visible next to the app so Hunter can edit approved websites later without rebuilding.

```powershell
python -m pip install pyinstaller
python -m PyInstaller --noconsole --onedir --name WandaSafeComputer wanda_launcher.py
Copy-Item config.json dist\WandaSafeComputer\config.json
```

Run:

```powershell
dist\WandaSafeComputer\WandaSafeComputer.exe
```

## Polished Delivery

Recommended final folder:

```text
C:\Program Files\Secure Tech Solutions\WandaSafeComputer
```

Desktop shortcut name:

```text
Wanda's Safe Computer
```

Start menu shortcut:

```text
Wanda's Safe Computer
```

## Fullscreen Mode

Press `F11` to toggle fullscreen. Press `Esc` to leave fullscreen.

For a kiosk-like feel, launch the app and press `F11`, but do not use Windows kiosk mode unless Wanda truly only needs this launcher.
