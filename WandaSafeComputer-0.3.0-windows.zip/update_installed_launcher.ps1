param(
    [string]$SourceFolder = $PSScriptRoot,
    [string]$InstallFolder = "C:\ProgramData\Secure Tech Solutions\WandaSafeComputer",
    [switch]$RestartLauncher
)

$ErrorActionPreference = "Stop"

$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator
)

if (-not $isAdmin) {
    $argsList = @(
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        "`"$PSCommandPath`"",
        "-SourceFolder",
        "`"$SourceFolder`"",
        "-InstallFolder",
        "`"$InstallFolder`""
    )
    if ($RestartLauncher) {
        $argsList += "-RestartLauncher"
    }
    Start-Process powershell.exe -Verb RunAs -ArgumentList $argsList
    exit
}

$distFolder = Join-Path $SourceFolder "dist\WandaSafeComputer"
$sourceExe = Join-Path $distFolder "WandaSafeComputer.exe"
$sourceInternal = Join-Path $distFolder "_internal"

if (-not (Test-Path -LiteralPath $sourceExe)) {
    throw "Built launcher not found: $sourceExe"
}

New-Item -ItemType Directory -Path $InstallFolder -Force | Out-Null

$runningLauncher = Get-Process -Name "WandaSafeComputer" -ErrorAction SilentlyContinue
if ($runningLauncher) {
    $runningLauncher | Stop-Process -Force
    Start-Sleep -Seconds 2
}

Copy-Item -LiteralPath $sourceExe -Destination (Join-Path $InstallFolder "WandaSafeComputer.exe") -Force

if (Test-Path -LiteralPath $sourceInternal) {
    $installedInternal = Join-Path $InstallFolder "_internal"
    if (Test-Path -LiteralPath $installedInternal) {
        Remove-Item -LiteralPath $installedInternal -Recurse -Force
    }
    Copy-Item -LiteralPath $sourceInternal -Destination $installedInternal -Recurse -Force
}

$copyNames = @(
    "config.json",
    "README.md",
    "HANDOFF_PRINT_OUT.md",
    "set_openai_key.ps1",
    "launch_for_wanda.cmd",
    "update_installed_launcher.ps1"
)

foreach ($name in $copyNames) {
    $source = Join-Path $SourceFolder $name
    if (Test-Path -LiteralPath $source) {
        Copy-Item -LiteralPath $source -Destination (Join-Path $InstallFolder $name) -Force
    }
}

"Updated: $(Get-Date -Format s)" | Set-Content -LiteralPath (Join-Path $InstallFolder "last-update.txt")

if ($RestartLauncher) {
    Start-Process -FilePath (Join-Path $InstallFolder "WandaSafeComputer.exe")
}

Write-Host "Wanda's Safe Computer was updated."
Write-Host "If RestartLauncher was not used, reopen it from Wanda's desktop shortcut."
